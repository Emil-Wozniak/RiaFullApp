package org.ria.ifzz.RiaApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RiaAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(RiaAppApplication.class, args);
	}

}

